package modelos;

/**
 *
 * @author 
 */
public class Producto {
    
    private int codigoProd, precioProd, existenciaProd;
    private String nombreProd;
    
    public Producto () {
        
    }

    public Producto(int codigoProducto, int precioProducto, int existenciaProducto, String nombreProducto) {
        this.codigoProd = codigoProducto;
        this.precioProd = precioProducto;
        this.existenciaProd = existenciaProducto;
        this.nombreProd = nombreProducto;
    }

    public int getCodigoProd() {
        return codigoProd;
    }

    public void setCodigoProd(int codigoProd) {
        this.codigoProd = codigoProd;
    }

    public int getPrecioProd() {
        return precioProd;
    }

    public void setPrecioProd(int precioProd) {
        this.precioProd = precioProd;
    }

    public int getExistenciaProd() {
        return existenciaProd;
    }

    public void setExistenciaProd(int existenciaProd) {
        this.existenciaProd = existenciaProd;
    }

    public String getNombreProd() {
        return nombreProd;
    }

    public void setNombreProd(String nombreProd) {
        this.nombreProd = nombreProd;
    }
    
}
